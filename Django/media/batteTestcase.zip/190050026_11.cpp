#include <bits/stdc++.h> 
using namespace std; 
 
void find_paths(vector<vector<int> >& paths, vector<int>& path, vector<int> parent[], int n, int u){  
	if (u == -1) { paths.push_back(path); return; }
 
	for (int par : parent[u]) { 
		path.push_back(u); 

		find_paths(paths, path, parent, n, par);  
		path.pop_back(); 
	} 
} 

void bfs(vector<int> adj[], vector<int> parent[], int n, int start){ 
	vector<int> dist(n, INT_MAX);

	queue<int> q; 

	q.push(start); 
	parent[start] = { -1 }; 
	dist[start] = 0; 

	while (!q.empty()) { 
		int u = q.front(); 
		q.pop(); 
		for (int v : adj[u]) { 
			if (dist[v] > dist[u] + 1) { 
				dist[v] = dist[u] + 1; 
				q.push(v); 
				parent[v].clear(); 
				parent[v].push_back(u); 
			} 
			else if (dist[v] == dist[u] + 1) {
				parent[v].push_back(u); 
			} 
		} 
	} 
} 

void walks(vector<int> adj[], int n, int start, int end) { 
	vector<vector<int>> paths; 
	vector<int> path; 
	vector<int> parent[n];
	vector<int> out; 

	bfs(adj, parent, n, start); 

	find_paths(paths, path, parent, n, end);

	if(paths.size()>0){
		cout << "possible" << endl;
		cout << paths[0].size()/2 << endl;
		for (auto v : paths) out.push_back(v[v.size()/2]/2);
		set<int> s(out.begin(), out.end());
		for(int v : s) cout << v << " ";
		cout << endl;
	}
	else {cout << "impossible" << endl;} 
} 

int main(){
	int n, m, u, v;
	cin >> n >> m >> u >> v;
	
	vector<int> adj[2*n+1]; 

	for(int i=0; i<m; i++){
		int a, b;
		cin >> a >> b;
		adj[2*a].push_back(2*b+1); 
		adj[2*b+1].push_back(2*a);
		adj[2*a+1].push_back(2*b); 
		adj[2*b].push_back(2*a+1);
	}

	walks(adj, 2*n+1, 2*u, 2*v); 
}