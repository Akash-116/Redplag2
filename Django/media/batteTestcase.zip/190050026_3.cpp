#include<bits/stdc++.h>
using namespace std;

int n;
long long int num_with_start(int length, int max){
	if(length==n) return 1;
	else return ((max+1)*(num_with_start(length+1,max))+num_with_start(length+1,max+1));
}

long long int seq_rank(int rgs[], long long int values[100][100]){
	long long int rank;
	int max=0;
	for(int i=1;i<n;i++){
		for(int j=0;j<rgs[i];j++){
			if(j>max) rank+=values[i][j];
			else rank+=values[i][max];
		}
		if(rgs[i]>max) max=rgs[i];
	}
	return rank;
}

void rank_seq(long long int rank, int rgs[], long long int values[100][100]){
	rgs[0]=0;
	int max=0;
	for(int i=1; i<n; i++){
		for(int j=0;j<=i;j++){
			if(j>max){
				if(rank<values[i][j]) rgs[i]=j;
				if(rgs[i]!=j) rank-=values[i][j];
			}
			else{
				if(rank<values[i][max]) rgs[i]=j;
				if(rgs[i]!=j) rank-=values[i][max];
			}
			if(rgs[i]==j) break;
		}
		if(rgs[i]>max) max=rgs[i];
	}
}

int main(){
	ios::sync_with_stdio(false);
	int t;
	long long int rank;
	char command;
	cin >> n >> t;
	int rgs[n];
	long long int values[100][100];
	for(int i=0; i<n; i++){
		for(int j=0; j<=i; j++){
			values[i][j]=num_with_start(i+1,j);
			}
	}
	for(int i=0; i<t; i++){
		cin >> command;
		if(command=='R'){
			for(int j=0; j<n; j++){
				cin >> rgs[j];
			}
			cout << seq_rank(rgs,values) << endl;
		}
		else if(command=='U'){
			cin >> rank;
			for(int j=0;j<n;j++){
				rgs[j]=-1;
			}
			rank_seq(rank, rgs, values);
			for(int j=0; j<n; j++){
				cout << rgs[j] << " ";
			}
			cout << endl;
		}
		else break;
	}
}