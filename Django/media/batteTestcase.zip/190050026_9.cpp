#include<bits/stdc++.h>
using namespace std;

struct trip{
	int first;
	int second;
	int ind;
};

struct compare{
	bool operator()(trip const &t1, trip const &t2){
		if(t1.first < t2.first) return true;
		if((t1.first==t2.first)&&(t1.second<t2.second)) return true;
		if((t1.first==t2.first)&&(t1.second==t2.second)&&(t1.ind<t2.ind)) return true;
		return false;
	}
};

struct compare1{
	bool operator()(trip const &t1, trip const &t2){
		if(t1.second < t2.second) return true;
		if((t1.second == t2.second)&&(t1.ind<t2.ind)) return true;
		return false;
	}
};

int main(){
	int n;
	cin >> n;
	vector<trip> S1(n);
	vector<trip> S2(n);

	for(int i=0; i<n; i++) cin >> S1[i].first;
	for(int i=0; i<n; i++) {cin >> S1[i].second; S1[i].ind = i+1;}
	for(int i=0; i<n; i++) cin >> S2[i].first;
	for(int i=0; i<n; i++) {cin >> S2[i].second; S2[i].ind = i+1;}

	sort(S1.begin(), S1.end(), compare());
	sort(S2.begin(), S2.end(), compare());

	vector<set<trip,compare1>> V1;
	set<trip,compare1> vec1; vec1.insert(S1[0]); V1.push_back(vec1);
	vector<set<trip,compare1>> V2;
	set<trip,compare1> vec2; vec2.insert(S2[0]); V2.push_back(vec2);

	vector<set<trip,compare1>> V3;
	set<trip,compare1> vec3; vec3.insert(S1[0]); V3.push_back(vec3);
	vector<set<trip,compare1>> V4;
	set<trip,compare1> vec4; vec4.insert(S2[0]); V4.push_back(vec4);

	for(int i=1; i<n; i++){
		if(S1[i].first>S1[i-1].first){
			set<trip,compare1> vec; vec.insert(S1[i]); V1.push_back(vec);
		}
		else V1[V1.size()-1].insert(S1[i]);
		if(S2[i].first>S2[i-1].first){
			set<trip,compare1> vec; vec.insert(S2[i]); V2.push_back(vec);
		}
		else V2[V2.size()-1].insert(S2[i]);
	}

	vector<int> p;
	vector<int> q;

	int i1 = 0;
	int i2 = 0;

	vector<int> p1;
	vector<int> q1;

	int i3 = 0;
	int i4 = 0;

	while(p.size()<n){
		if(V1[i1].size()<=V2[i2].size()){
			set<trip,compare1>::iterator it1 = V1[i1].begin();
			for(int i=0; i<V1[i1].size(); i++){
				set<trip,compare1>::iterator it;
				trip T = *it1;
				T.ind=n+1;
				it = V2[i2].upper_bound(T);
				if (it == V2[i2].begin()) goto fail;
				--it;
				p.push_back(it1->ind);
				q.push_back(it->ind);
				V2[i2].erase(it);
				it1++;
			}
			i1++;
		}
		else{
			set<trip,compare1>::iterator it1 = V2[i2].begin();
			for(int i=0; i<V2[i2].size(); i++){
				set<trip,compare1>::iterator it;
				trip T = *it1;
				T.ind=0;
				it = V1[i1].lower_bound(T);
				if(it == V1[i1].end()) goto fail;
				p.push_back(it->ind);
				q.push_back(it1->ind);
				V1[i1].erase(it);
				it1++;
			}
			i2++;
		}
	}

	for(int i=0; i<n; i++) cout << p[i] << " ";
	cout << endl;
	for(int i=0; i<n; i++) cout << q[i] << " ";
	cout << endl;	

	for(int i=1; i<n; i++){
		if(S1[i].first>S1[i-1].first){
			set<trip,compare1> vec; vec.insert(S1[i]); V3.push_back(vec);
		}
		else V3[V3.size()-1].insert(S1[i]);
		if(S2[i].first>S2[i-1].first){
			set<trip,compare1> vec; vec.insert(S2[i]); V4.push_back(vec);
		}
		else V4[V4.size()-1].insert(S2[i]);
	}

	while(p1.size()<n){
		if(V3[i3].size()<=V4[i4].size()){
			set<trip,compare1>::iterator it1 = V3[i3].begin();
			for(int i=0; i<V3[i3].size(); i++){
				set<trip,compare1>::iterator it;
				it = V4[i4].begin();
				p1.push_back(it1->ind);
				q1.push_back(it->ind);
				V4[i4].erase(it);
				it1++;
			}
			i3++;
		}
		else{
			set<trip,compare1>::iterator it1 = V4[i4].begin();
			for(int i=0; i<V4[i4].size(); i++){
				set<trip,compare1>::iterator it;
				it = V3[i3].end();
				--it;
				p1.push_back(it->ind);
				q1.push_back(it1->ind);
				V3[i3].erase(it);
			}
			i4++;
		}
	}

	for(int i=0; i<n; i++){
		if((p[i]!=p1[i])||(q[i]!=q1[i])) goto not_unique;
	}

	cout << "unique" << endl;

	return 0;

	not_unique:
		cout << "not unique" << endl;

	return 0;

	fail:
		cout << "impossible" << endl;
}