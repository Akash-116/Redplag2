#include<bits/stdc++.h>
using namespace std;

int operations(string inp, string rep){
	int n1 = inp.length();
	int n2 = rep.length();
	int out;
	if(n1%n2==0) out=0;
	else out=n2-n1%n2;

	for(int i=0;i<n1/n2;i++){
		for(int j=0;j<n2;j++){
			if(inp[i*n2+j]!=rep[j]) out++;
		}
	}

	for(int i=n2*(n1/n2);i<n1;i++){
		if(inp[i]!=rep[i%n2]) out++;
	}

	return out;
}

int main(){
	string input;
	int k;
	int a1=0;
	int a2;
	cin >> input >> k;
	k=input.length()/k;
	int k2;

	for(int i=0;i<k;i++){
		int arr[26]={0};
		int max=-1;
		int max_ind;
		for(int j=0;j<(input.length()/k);j++){
			arr[input[i+j*k]-97]++;
		}
		for(int j=0;j<26;j++){
			if(arr[j]>max){
				max=arr[j];
				max_ind=j;
			}
		}
		for(int j=0;j<26;j++){
			if((arr[j])&&(j!=max_ind)) a1+=arr[j];
		}
	}

	cout<<a1<<endl;
	a2=a1;

	for(int i=1;i<input.length();i++){
		for(int j=0;j<input.length()/i;j++){
		string repeat = input.substr(i*j,i);
		int b = operations(input, repeat);
		if(b<=a2){
			a2=b;
			if(input.length()%i==0) k2=input.length()/i;
			else k2=input.length()/i + 1;
		}}
	}

	cout<<a2<<" "<<k2<<endl;
}