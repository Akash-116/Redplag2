#include<bits/stdc++.h>
using namespace std;

int main(){
	int n;
	cin >> n;

	int f[n];
	for(int i=0;i<n;i++) cin >> f[i];

	int l[n];
	l[0] = -1;
	for(int i=1;i<n;i++){
		int j = i-1;

		while((j>=0)&&(f[j]<f[i])) j = l[j];

		l[i] = j;
	}

	int s[n];
	s[0] = -1;
	for(int i=1;i<n;i++){
		int j = i-1;

		while((j>=0)&&(f[j]<=f[i])) j = s[j];

		s[i] = j;
	}

	int g[n];
	g[n-1] = n;
	for(int i=n-2;i>=0;i--){
		int j = i+1;

		while((j<n)&&(f[j]<f[i])) j = g[j];

		g[i] = j;
	}

	long long int out[n];
	long long int sum = 0;
	for(int i=0;i<n;i++){
		out[i] = (i-l[i])*(g[i]-i);
		cout<< out[i] << " ";
	}

	for(int i=0;i<n;i++){
		int min = f[i];
		for(int j = i; j>=s[i]+1;j--){
			if(f[j]<=min) {min = f[j];sum++;}
		}
	}

	cout << endl << sum << endl;
}