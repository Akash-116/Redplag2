#include<bits/stdc++.h>
using namespace std;

int divide(int n, int k){
	if(n%k==0) return n/k;
	else return n/k+1;
}

void part2(int out[2], int k, string inp){
	int steps=0;
	int time=0;

	stack<char> s1;
	stack<int> s2;
	for(int i=0; i<inp.length(); i++){
		if(inp[i]=='e') {s1.push('e'); s2.push(0);}
		if(inp[i]=='*'){
			int l=1;
			char c1 = s1.top();
			s1.pop();
			char c2 = s1.top();
			s1.pop();
			int l1 = s2.top();
			s2.pop();
			int l2 = s2.top();
			s2.pop();

			if(c1=='*') l+=l1;
			if(c2=='*') l+=l2;
			
			if((c1=='*')&&(c2=='*')&&(l>=k)){
				if((l1==k-1)&&(l2==k-1)) {steps+=2;l=1;}
				else if(l1==k-1) {steps++; l-=l1;}
				else if(l2==k-1) {steps++; l-=l2;}
				else{
					if(l1>l2) {steps++; l-=l1;}
					else {steps++; l-=l2;}
				}
			}
			if((c1=='+')&&(c2=='+')){steps+=2;}
			if((c1=='*')&&(c2=='e')&&(l==k)){steps++; l=1;}
			if((c1=='e')&&(c2=='*')&&(l==k)){steps++; l=1;}
			if((c1=='*')&&(c2=='+')&&(l==k)){steps+=2; l=1;}
			if((c1=='+')&&(c2=='*')&&(l==k)){steps+=2; l=1;}
			if((c1=='*')&&(c2=='+')&&(l<k)){steps++;}
			if((c1=='+')&&(c2=='*')&&(l<k)){steps++;}
			if((c1=='+')&&(c2=='e')){steps++;}
			if((c1=='e')&&(c2=='+')){steps++;}

			s1.push('*');
			s2.push(l);
		}
		if(inp[i]=='+'){
			int l=1;
			char c1 = s1.top();
			s1.pop();
			char c2 = s1.top();
			s1.pop();
			int l1 = s2.top();
			s2.pop();
			int l2 = s2.top();
			s2.pop();

			if(c1=='+') l+=l1;
			if(c2=='+') l+=l2;
			
			if((c1=='+')&&(c2=='+')&&(l>=k)){
				if((l1==k-1)&&(l2==k-1)) {steps+=2;l=1;}
				else if(l1==k-1) {steps++; l-=l1;}
				else if(l2==k-1) {steps++; l-=l2;}
				else{
					if(l1>l2) {steps++; l-=l1;}
					else {steps++; l-=l2;}
				}
			}
			if((c1=='*')&&(c2=='*')){steps+=2;}
			if((c1=='+')&&(c2=='e')&&(l==k)){steps++; l=1;}
			if((c1=='e')&&(c2=='+')&&(l==k)){steps++; l=1;}
			if((c1=='+')&&(c2=='*')&&(l==k)){steps+=2; l=1;}
			if((c1=='*')&&(c2=='+')&&(l==k)){steps+=2; l=1;}
			if((c1=='+')&&(c2=='*')&&(l<k)){steps++;}
			if((c1=='*')&&(c2=='+')&&(l<k)){steps++;}
			if((c1=='*')&&(c2=='e')){steps++;}
			if((c1=='e')&&(c2=='*')){steps++;}

			s1.push('+');
			s2.push(l);
		}
	}
	out[0]=steps+1; out[1]=time;
	return;
}

int main(){
	string inp;
	cin >> inp;
	//part1
	stack<char> s;
	stack<int> s1;
	int steps=0;
	for(int i=0; i<inp.length(); i++){
		if(inp[i]=='e') {s.push('e'); s1.push(0);}
		if(inp[i]=='*'){
			char c1 = s.top();
			s.pop();
			char c2 = s.top();
			s.pop();
			int l1 = s1.top();
			s1.pop();
			int l2 = s1.top();
			s1.pop();
			int l;
			if((c1=='+')||(c2=='+')){
				if((c1=='+')&&(c2=='+')) {steps+=2;}
				else {steps++;}
			}
			if((c1=='*')&&(c2=='*')){
				if(l1>=l2) l=l1;
				else l=l2;
			}
			if((c1!='*')&&(c2=='*')){
				if(l1>=l2) l=l1+1;
				else l=l2;
			}
			if((c1=='*')&&(c2!='*')){
				if(l2>=l1) l=l2+1;
				else l=l1;
			}
			if((c1!='*')&&(c2!='*')){
				if(l2>=l1) l=l2+1;
				else l=l1+1;
			}
			s.push('*');
			s1.push(l);
		}
		if(inp[i]=='+'){
			char c1 = s.top();
			s.pop();
			char c2 = s.top();
			s.pop();
			int l1 = s1.top();
			s1.pop();
			int l2 = s1.top();
			s1.pop();
			int l;
			if((c1=='*')||(c2=='*')){
				if((c1=='*')&&(c2=='*')) {steps+=2;}
				else {steps++;}
			}
			if((c1=='+')&&(c2=='+')){
				if(l1>=l2) l=l1;
				else l=l2;
			}
			if((c1!='+')&&(c2=='+')){
				if(l1>=l2) l=l1+1;
				else l=l2;
			}
			if((c1=='+')&&(c2!='+')){
				if(l2>=l1) l=l2+1;
				else l=l1;
			}
			if((c1!='+')&&(c2!='+')){
				if(l2>=l1) l=l2+1;
				else l=l1+1;
			}
			s.push('+');
			s1.push(l);
		}
	}
	cout << steps+1 << " " << s1.top() << endl;
	//////////////////////////////////part 1 done/////////////////////////////////////
	int test;
	cin >> test;
	for(int i=0; i<test; i++){
		int k;
		cin >> k;
		int a[2];
		part2(a, k, inp);
		cout << a[0] << " " << a[1] << endl;
	}
}