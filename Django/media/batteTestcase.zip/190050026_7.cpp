#include<bits/stdc++.h>
using namespace std;

map<string, vector<int>> students;
map<string, vector<int>> courses;
map<string, set<string>> students_courses;
map<string, set<string>> courses_students;

int num_courses, num_students, max_reg, num_ops;

int a[100000][1000] = {0};

bool Register(string roll, string course){;

	auto it1 = students_courses[roll].find(course);

	if(it1!=students_courses[roll].end()) return false;

	if(courses[course][2]==courses[course][1]) return false;

	if(students[roll][0]==max_reg) return false;

	if(find(next(students[roll].begin()), students[roll].end(), courses[course][0]) != students[roll].end()) return false;

	courses[course][2]++; students[roll][0]++; students[roll].push_back(courses[course][1]);

	students_courses[roll].insert(course);

	courses_students[course].insert(roll);
	return true;
}

bool Drop(string roll, string course){
	auto it1 = students_courses[roll].find(course);

	if(it1==students_courses[roll].end()) return false;

	courses[course][2]--; students[roll][0]--; remove(students[roll].begin(), students[roll].end(), courses[course][1]);

	students_courses[roll].erase(students_courses[roll].find(course));

	courses_students[course].erase(courses_students[course].find(roll));
	return true;
}

void Print(string command){
	if(command.length()==9){
		auto it1 = students_courses.find(command);
		set<string> s = it1->second;
		for(auto it = s.begin(); it!=s.end(); ++it){
			cout << *it << " ";
		}
		cout << endl;
		return;
	}

	if(command.length()==6){
		auto it1 = courses_students.find(command);
		set<string> s = it1->second;
		for(auto it = s.begin(); it!=s.end(); ++it){
			cout << *it << " ";
		}
		cout << endl;
		return;
	}

	if(command.length()==19){
		auto it1 = students_courses.find(command.substr(0,9));
		auto it2 = students_courses.find(command.substr(10,9));
		set<string> s;
		set_intersection(it1->second.begin(), it1->second.end(), it2->second.begin(), it2->second.end(), inserter(s, s.begin()));
		for(auto st = s.begin(); st!= s.end(); ++st){
			cout << *st << " ";
		}
		cout << endl;
	}

	if(command.length()==13){
		auto it1 = courses_students.find(command.substr(0,6));
		auto it2 = courses_students.find(command.substr(7,6));
		set<string> s;
		set_intersection(it1->second.begin(), it1->second.end(), it2->second.begin(), it2->second.end(), inserter(s, s.begin()));
		for(auto st = s.begin(); st!= s.end(); ++st){
			cout << *st << " ";
		}
		cout << endl;
	}
}

int main(){
	#define fio ios_base::sync_with_stdio(false);cin.tie(NULL);cout.tie(NULL);
	
	cin >> num_courses >> num_students >> max_reg >> num_ops;;

	for(int i=0;i<num_courses;i++){
		string course;
		int slot;
		int max_reg;
		cin >> course >> slot >> max_reg;
		vector<int> v; v.push_back(slot); v.push_back(max_reg); v.push_back(0);
		courses.insert({course, v});
		set<string> s;
		courses_students.insert({course, s});
	}

	for(int i=0;i<num_students;i++){
		string roll;
		cin >> roll;
		vector<int> v; v.push_back(0);
		students.insert({roll,v});
		set<string> s;
		students_courses.insert({roll, s});
	}

	for(int i=0; i<num_ops; i++){
		char op;
		cin >> op;
		if (op=='R'){
			string roll;
			string course;
			cin >> roll >> course;
			if(Register(roll, course)) cout << "success" << endl;
			else cout << "fail" << endl;
			continue;
		}
		else if (op=='D'){
			string roll;
			string course;
			cin >> roll >> course;
			if(Drop(roll, course)) cout << "success" << endl;
			else cout << "fail" << endl;
			continue;
		}
		else if (op=='P'){
			string command;
			cin >> command;
			Print(command);
		}
	}
}