#include<bits/stdc++.h>
using namespace std;

int m=0;
void reorder(int a[], int k, int i){
	int b=a[i];
	a[i]=0;
	for(int j=1; j<=b; j++){
		a[((i+j)%k)]++;
	}
}

int argmin(int a[], int n, int k){
	int min=n+1;
	int argmin;
	for(int i=0; i<k; i++){
		if((a[i]<min)&&(a[i]>0)) {min=a[i]; argmin=i;}
	}
	m=min;
	return argmin;
}

int main(){
	int n,k,min;
	cin >> n >> k;
	int a[k];
	for(int i=0; i<k; i++){
		cin>>a[i];
	}

	min=argmin(a,n,k);
	while(m!=n){
		cout<<min<<" ";
		reorder(a,k,min);
		min=argmin(a,n,k);
	}
	cout<<min<<endl;
	reorder(a,k,min);
}