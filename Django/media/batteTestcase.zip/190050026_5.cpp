#include<bits/stdc++.h>
using namespace std;

int main(){
	int n;
	cin>>n;
	long long int f[(1<<n)]={0};
	long long int F[(1<<n)]={0};
	for(int i=0;i<(1<<n);i++){
		cin>>f[i];
		F[i]=f[i];
	}
	for(int i=0;i<n;i++){
		for(int j=0;j<(1<<n);j++){
			if((1<<i)&j){
				F[j]+=F[(1<<i)^j];
			}
		}
	}
	for(int i=0;i<(1<<n);i++){
		cout<<F[i]<<" ";
	}
	cout<<endl;
	long long int f_new[(1<<n)]={0};
	long long int F_new[(1<<n)]={0};
	for(int i=0;i<(1<<n);i++){
		int x;
		cin>>x;
		if(x==0){
			f_new[i]=f[i];
			for(int j=0;j<=i;j++){
				if((i&j)==j) F_new[i]+=f_new[j];
			}
			cout<<F_new[i]<<" ";
		}
		else{
			F_new[i]=f[i];
			f_new[i]=F_new[i];
			for(int j=0;j<i;j++){
				if((i&j)==j){
					f_new[i]=f_new[i]-f_new[j];
				}
			}
			cout<<f_new[i]<<" ";
		}
	}
	cout<<endl;
}