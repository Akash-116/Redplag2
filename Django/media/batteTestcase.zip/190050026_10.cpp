#include<bits/stdc++.h>
using namespace std;

vector<vector<bool>> bin;
vector<vector<int>> final;

int hash_func(string &s){
	int out=0;
	for(int i=0; i<s.length(); i++){
		if(s[i]=='1') out++;
	}
	return out;
}

bool equiv(string &s1, string &s2, int n){
	if(s1[0]!=s2[0]) return false;
	if(s1==s2) return true;
	int per[n];
	int power_n = (1<<n);
	if(s1[power_n-1]!=s2[power_n-1]) return false;
	for(int i=0; i<n; i++) per[i]=i;
	int n_fac= final[0].size();
	for(int num=0; num<n_fac; num++){
		int flag = 1;
		for (int i=0; i<power_n; i++){
			int k=final[i][num];
			if (s1[i]!=s2[k]) {flag = 0; continue;}
		}
		if(flag==1) return true;
	}
	return false;
}

int main(){
	int n, m, output=0;
	cin >> n >> m;
	int power_n = (1<<n);
	string inputs[m];
	for(int i=0; i<m; i++){
		cin >> inputs[i];
	}
	for(int i=0; i<power_n; i++){
		vector<bool> v1;
		bin.push_back(v1);
		for(int j=0; j<n; j++) bin[i].push_back(i&(1<<j));
	}
	int per[n];
	for(int i=0; i<n; i++) per[i]=i;
	for(int i=0; i<power_n; i++){
		vector<int> v; v.push_back(i);
		final.push_back(v);
	}
	while(next_permutation(per, per+n)){
		for(int i=0; i<power_n; i++){
			int k = 0;
			for (int j=0; j<n; j++) k+=(bin[i][per[j]])*(1<<j);
			final[i].push_back(k);
		}
	}
	map<int, vector<string*>> hash_groups;
	for(int i=0; i<m; i++){
		int flag=0;
		int hash_value = hash_func(inputs[i]);
		int len = hash_groups[hash_value].size();
		for(int j=0; j<len; j++){
			if(equiv(*hash_groups[hash_value][j], inputs[i], n)) {flag=1;continue;}
		}
		if(flag==0) {hash_groups[hash_value].push_back(&inputs[i]); output++;}
	}
	cout << output << endl;
}