#include<bits/stdc++.h>
using namespace std;

int main(){
	int n,m;
	cin >> n >> m;
	unordered_set<int> edges[n];
	for(int i=0; i<m; i++){
		int a,b;
		cin >> a >> b;
		edges[a].insert(b);
		edges[b].insert(a);
	}
	int deleted=0;
	queue<int> nodes;
	for(int i=0; i<n; i++){
		int s = edges[i].size();
		if((s<=2)&&(s>0)) nodes.push(i);
	}
	while(nodes.size()!=0){
		int k = nodes.front(); nodes.pop();
		int s = edges[k].size();
		if(s==1){
			auto it = edges[k].begin();
			int a = *it;
			int s1 = edges[a].size();
			edges[a].erase(k);
			int s2 = edges[a].size();
			if(s2==0) deleted++;
			if((s1>2)&&(s2<=2)&&(s2>0)) nodes.push(a);
			edges[k].clear();
			deleted++;
		}
		if(s==2){
			auto it = edges[k].begin();
			int a1 = *it; it++;
			int a2 = *it;
			int s1 = edges[a1].size(); int s2 = edges[a2].size();
			edges[a1].erase(k); edges[a2].erase(k);
			edges[a1].insert(a2); edges[a2].insert(a1);
			int s3 = edges[a1].size(); int s4 = edges[a2].size();
			if((s1>2)&&(s3<=2)) nodes.push(a1);
			if((s2>2)&&(s4<=2)) nodes.push(a2);
			edges[k].clear();
			deleted++;
		}
	}
	if(deleted==n) cout << "yes" << endl;
	else cout << "no" << endl;
	///////////////////////////////////////////////////////////////
	
}